# AtLarge BSc thesis template
A LaTeX template for creating BSc theses

Usage:
1. Clone or download this repository
2. Upload the code to Overleaf as a new project
3. Share your Overleaf project via Slack and/or the rolling log
